// 03 - C# QuickStart & Developing in C#\Enums
// copyright 2000 Eric Gunnerson
enum Colors
{
    red,
    green,
    blue
}