// 03 - C# QuickStart & Developing in C#\Basic Data Types
// copyright 2000 Eric Gunnerson
using System;
class Hello
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Value is: {0}", 3);
    }
}