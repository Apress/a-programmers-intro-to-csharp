// 03 - C# QuickStart & Developing in C#\Developing in C#\Other Tools of Note\ILDASM
// copyright 2000 Eric Gunnerson
using System;
class Test
{
    public static void Main()
    {
        Console.WriteLine("Hello " + "World");
    }
}