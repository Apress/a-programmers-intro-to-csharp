// 03 - C# QuickStart & Developing in C#\Namespaces and Using
// copyright 2000 Eric Gunnerson
using ThatConsoleClass = System.Console;
class Hello
{
    public static void Main()
    {
        ThatConsoleClass.WriteLine("Hello");
    }
}