// 03 - C# QuickStart & Developing in C#\Namespaces and Using
// copyright 2000 Eric Gunnerson
namespace Outer
{
    namespace Inner
    {
        class MyClass
        {
            public static void Function() {}
        }
    }
}