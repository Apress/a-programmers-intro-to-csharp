// 26 - Other Language Details\Lexical Details\Identifiers
// copyright 2000 Eric Gunnerson
class Test
{
    public void @checked()
    {
    }
}