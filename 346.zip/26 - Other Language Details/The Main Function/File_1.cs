// 26 - Other Language Details\The Main Function
// copyright 2000 Eric Gunnerson
using System;
class Test
{
    public static void Main()
    {
        Console.WriteLine("Hello, Universe!");
    }
}