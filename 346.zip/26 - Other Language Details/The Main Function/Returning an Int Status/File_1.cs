// 26 - Other Language Details\The Main Function\Returning an Int Status
// copyright 2000 Eric Gunnerson
using System;
class Test
{
    public static int Main()
    {
        Console.WriteLine("Hello, Universe!");
        return(0);
    }
}