// 39 - C# Compared to Other Languages\Differences Between C# and Java\Data Types
// copyright 2000 Eric Gunnerson
using System;
class Test
{
    public static void Main()
    {
        Console.WriteLine(5.ToString());
    }
}