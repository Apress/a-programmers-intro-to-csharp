// 06 - Base Classes and Inheritance\Sealed Classes and Methods
// copyright 2000 Eric Gunnerson
// error
sealed class MyClass
{
    MyClass() {}
}
class MyNewClass : MyClass
{
}