// 05 - Classes 101\A Simple Class
// copyright 2000 Eric Gunnerson
class VerySimple
{
    int    simpleValue = 0;
}
class Test
{
    public static void Main()
    {
        VerySimple vs = new VerySimple();
    }
}