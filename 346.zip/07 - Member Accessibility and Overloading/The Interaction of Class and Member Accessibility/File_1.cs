// 07 - Member Accessibility and Overloading\The Interaction of Class and Member Accessibility
// copyright 2000 Eric Gunnerson
internal class MyHelperClass
{
    public void PublicFunction() {}
    internal void InternalFunction() {}
    protected void ProtectedFunction() {}
}