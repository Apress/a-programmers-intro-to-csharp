﻿// polynomial evaluator
// Evaluating y = 5.5

class Poly_1000: PolyInterface.IPolynomial
{
public double Eval(double value)
{
	return(
		5.5
	);
}
}
