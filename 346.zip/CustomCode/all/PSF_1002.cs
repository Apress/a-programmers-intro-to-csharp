﻿// polynomial evaluator
// Evaluating y = 0 + 1 X^1 + 2 X^2 + 3 X^3 + 4 X^4 + 5 X^5 + 6 X^6 + 7 X^7 + 8 X^8 + 9 X^9 + 10 X^10 + 11 X^11 + 12 X^12 + 13 X^13 + 14 X^14 + 15 X^15 + 16 X^16 + 17 X^17 + 18 X^18 + 19 X^19 + 20 X^20 + 21 X^21 + 22 X^22 + 23 X^23 + 24 X^24 + 25 X^25 + 26 X^26 + 27 X^27 + 28 X^28 + 29 X^29 + 30 X^30 + 31 X^31 + 32 X^32 + 33 X^33 + 34 X^34 + 35 X^35 + 36 X^36 + 37 X^37 + 38 X^38 + 39 X^39 + 40 X^40 + 41 X^41 + 42 X^42 + 43 X^43 + 44 X^44 + 45 X^45 + 46 X^46 + 47 X^47 + 48 X^48 + 49 X^49

class Poly_1002: PolyInterface.IPolynomial
{
public double Eval(double value)
{
	return(
		0
		+ value * (1 
		+ value * (2 
		+ value * (3 
		+ value * (4 
		+ value * (5 
		+ value * (6 
		+ value * (7 
		+ value * (8 
		+ value * (9 
		+ value * (10 
		+ value * (11 
		+ value * (12 
		+ value * (13 
		+ value * (14 
		+ value * (15 
		+ value * (16 
		+ value * (17 
		+ value * (18 
		+ value * (19 
		+ value * (20 
		+ value * (21 
		+ value * (22 
		+ value * (23 
		+ value * (24 
		+ value * (25 
		+ value * (26 
		+ value * (27 
		+ value * (28 
		+ value * (29 
		+ value * (30 
		+ value * (31 
		+ value * (32 
		+ value * (33 
		+ value * (34 
		+ value * (35 
		+ value * (36 
		+ value * (37 
		+ value * (38 
		+ value * (39 
		+ value * (40 
		+ value * (41 
		+ value * (42 
		+ value * (43 
		+ value * (44 
		+ value * (45 
		+ value * (46 
		+ value * (47 
		+ value * (48 
		+ value * (49 
	))))))))))))))))))))))))))))))))))))))))))))))))));
}
}
