﻿// Polynomial evaluator
// Evaluating Y = 5.5
public class Poly_1000 : PolyInterface.IPolynomial {
    
    public double Eval(double x) {
        return (5.5 + 0);
    }
}
