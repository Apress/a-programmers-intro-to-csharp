// 31 - Interop\Calling Native DLL Functions
// copyright 2000 Eric Gunnerson
using System.Runtime.InteropServices;
class Test
{
    [DllImport("user32.dll")]
    public static extern int MessageBox(int h, string m, 
    string c, int type);
    public static void Main()
    {
        int retval = MessageBox(0, "Hello", "Caption", 0);
    }
}