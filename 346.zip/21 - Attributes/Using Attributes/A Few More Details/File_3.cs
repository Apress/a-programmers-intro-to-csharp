// 21 - Attributes\Using Attributes\A Few More Details
// copyright 2000 Eric Gunnerson
using System;
[assembly:CLSCompliant(true)]

class Test
{
    Test() {}
}