// 21 - Attributes
// copyright 2000 Eric Gunnerson
using System.Diagnostics;
class Test
{
    [Conditional("DEBUG")]
    public void Validate()
    {
    }
}