// 18 - Properties\Accessors
// copyright 2000 Eric Gunnerson
class Test
{
    private string name;
    
    public string Name
    {
        get 
        {
            return name;
        }
        set 
        {
            name = value;
        }
    }
}