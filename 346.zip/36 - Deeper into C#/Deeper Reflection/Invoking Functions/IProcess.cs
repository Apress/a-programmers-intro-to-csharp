// 36 - Deeper into C#\Deeper Reflection\Invoking Functions
// copyright 2000 Eric Gunnerson
// file=IProcess.cs
namespace MamaSoft
{
    interface IProcess
    {
        string Process(int param);
    }
}