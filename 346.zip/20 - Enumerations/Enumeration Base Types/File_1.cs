// 20 - Enumerations\Enumeration Base Types
// copyright 2000 Eric Gunnerson
enum SmallEnum : byte
{
    A,
    B,
    C,
    D
}