// 20 - Enumerations\Initialization
// copyright 2000 Eric Gunnerson
enum Values
{
    A = 1,
    B = 2,
    C = A + B,
    D = A * C + 33
}