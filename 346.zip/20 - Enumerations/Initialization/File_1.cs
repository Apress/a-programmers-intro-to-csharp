// 20 - Enumerations\Initialization
// copyright 2000 Eric Gunnerson
enum Values
{
    A = 1,
    B = 5,
    C = 3,
    D = 42
}