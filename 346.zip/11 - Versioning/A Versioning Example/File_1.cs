// 11 - Versioning\A Versioning Example
// copyright 2000 Eric Gunnerson
public class Control
{
}
public class MyControl: Control
{
}