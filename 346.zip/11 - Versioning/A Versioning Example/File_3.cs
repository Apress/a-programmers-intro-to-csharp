// 11 - Versioning\A Versioning Example
// copyright 2000 Eric Gunnerson
public class Control
{
    // newly added virtual
    public virtual void Foo() {}
}
public class MyControl: Control
{
    public virtual void Foo() {}
}