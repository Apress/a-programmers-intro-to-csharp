// 32 - .NET Frameworks Overview\Numeric Formatting\Standard Format Strings\Hexadecimal
// copyright 2000 Eric Gunnerson
using System;
class Test
{
    public static void Main()
    {
    Console.WriteLine("{0:X}", 255);
    Console.WriteLine("{0:x8}", 1456);
    }
}