// 32 - .NET Frameworks Overview\Numeric Formatting\Standard Format Strings\Decimal
// copyright 2000 Eric Gunnerson
using System;
class Test
{
    public static void Main()
    {
    Console.WriteLine("{0:D}", 33345);
    Console.WriteLine("{0:D7}", 33345);
    }
}