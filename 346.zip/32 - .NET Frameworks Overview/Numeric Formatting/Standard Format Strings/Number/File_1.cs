// 32 - .NET Frameworks Overview\Numeric Formatting\Standard Format Strings\Number
// copyright 2000 Eric Gunnerson
using System;
class Test
{
    public static void Main()
    {
    Console.WriteLine("{0:N}", 33345.8977);
    Console.WriteLine("{0:N4}", 33345.8977);
    }
}