// 08 - Other Class Details\Static Constructors
// copyright 2000 Eric Gunnerson
using System;
class MyClass
{
    static MyClass()
    {
        Console.WriteLine("MyClass is initializing");
    }
}