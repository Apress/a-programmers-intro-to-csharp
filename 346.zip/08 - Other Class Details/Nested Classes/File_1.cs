// 08 - Other Class Details\Nested Classes
// copyright 2000 Eric Gunnerson
public class Parser
{
    Token[]    tokens;
}
public class Token
{
    string name;
}