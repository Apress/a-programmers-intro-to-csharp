namespace DiskDiff
{
    using System;
    using System.Drawing;
    using System.Collections;
    using System.ComponentModel;
    using System.Windows.Forms;

    /// <summary>
    ///    Summary description for DialogConfigure.
    /// </summary>
    public class DialogConfigure : System.Windows.Forms.Form
    {
        /// <summary>
        ///    Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components;
		private System.Windows.Forms.Button Cancel;
		private System.Windows.Forms.Button OK;
		private System.Windows.Forms.TextBox RootTextBox;
		private System.Windows.Forms.Label label1;

        public DialogConfigure()
        {
            //
            // Required for Windows Form Designer support
            //
            InitializeComponent();

            //
            // TODO: Add any constructor code after InitializeComponent call
            //
        }

		public string Root
		{
			get
			{
				return (RootTextBox.Text);
			}
			set
			{
				RootTextBox.Text = value;
			}
		}

        /// <summary>
        ///    Clean up any resources being used.
        /// </summary>
        public override void Dispose()
        {
            base.Dispose();
            components.Dispose();
        }

        /// <summary>
        ///    Required method for Designer support - do not modify
        ///    the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container ();
			this.label1 = new System.Windows.Forms.Label ();
			this.OK = new System.Windows.Forms.Button ();
			this.Cancel = new System.Windows.Forms.Button ();
			this.RootTextBox = new System.Windows.Forms.TextBox ();
			//@this.TrayHeight = 0;
			//@this.TrayLargeIcon = false;
			//@this.TrayAutoArrange = true;
			label1.Location = new System.Drawing.Point (8, 8);
			label1.Text = "Root:";
			label1.Size = new System.Drawing.Size (104, 16);
			label1.TabIndex = 0;
			OK.Location = new System.Drawing.Point (120, 64);
			OK.DialogResult = System.Windows.Forms.DialogResult.OK;
			OK.Size = new System.Drawing.Size (75, 23);
			OK.TabIndex = 2;
			OK.Text = "OK";
			Cancel.Location = new System.Drawing.Point (224, 64);
			Cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			Cancel.Size = new System.Drawing.Size (75, 23);
			Cancel.TabIndex = 3;
			Cancel.Text = "Cancel";
			RootTextBox.Location = new System.Drawing.Point (8, 32);
			RootTextBox.Text = "textBox1";
			RootTextBox.TabIndex = 1;
			RootTextBox.Size = new System.Drawing.Size (424, 20);
			this.Text = "DialogConfigure";
			this.AutoScaleBaseSize = new System.Drawing.Size (5, 13);
			this.CancelButton = this.Cancel;
			this.AcceptButton = this.OK;
			this.ClientSize = new System.Drawing.Size (440, 109);
			this.Controls.Add (this.Cancel);
			this.Controls.Add (this.OK);
			this.Controls.Add (this.RootTextBox);
			this.Controls.Add (this.label1);
		}
    }
}
