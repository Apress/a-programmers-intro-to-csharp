// 13 - Variable Scoping and Definite Assignment
// copyright 2000 Eric Gunnerson
using System;
class MyObject
{
    public MyObject(int x, int y)
    {
        this.x = x;
        this.y = y;
    }
    int x;
    int y;
}