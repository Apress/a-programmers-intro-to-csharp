// 13 - Variable Scoping and Definite Assignment\Definite Assignment
// copyright 2000 Eric Gunnerson
// error
using System;
class Test
{
    public static void Main()
    {
        int n;
        Console.WriteLine("Value of n is {0}", n);
    }
}