// 12 - Statements and Flow of Execution\Iteration Statements\For
// copyright 2000 Eric Gunnerson
using System;
class Test
{
    public static void Main()
    {
        for (int n = 0; n < 10; n++)
        Console.WriteLine("Number is {0}", n);
    }
}